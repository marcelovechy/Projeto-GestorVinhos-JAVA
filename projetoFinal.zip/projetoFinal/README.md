# Wine prices

Pretende-se desenvolver uma aplicação para a gestão e registo de vinhos e respetivos preços nas diferentes lojas.

## Definições
- Vinho: Marca de vinho. Por exemplo Cartuxa;
- Edição de Vinho: Edição é o equivalente a colheita. Por exemplo o vinho cartuxa possui edições anuais identificada pelo ano da colheita. Por exemplo Cartuxa 2019
- Tipo Vinho:Branco, Tinto, etc....
- País: País onde foi produzido o vinho
- Região: Região de um país onde foi produzido o vinho. Por exemplo Alentejo
- Produtor: Nome do produtor. 
- Vendedor: Loja ou vendedor que vende edições de vinho, que neste caso se designam produtos. Cada vendedor vende o seu produto (edição de vinho) com um determinado preço

## Diagrama de Classes
Abaixo apresenta-se o Diagrama de classes que ajuda a exemplificar o que se pretende.
![Diagrama](diagramaClasses.png)

Main View
![Diagrama Main](main.png)
## Funcionalidades 
### Menu Gerir Vinhos
- Adicionar País
- Adicionar Região de Produção
- Adicionar Produtor
- Adicionar Tipo de Vinho
- Adicionar Vinho
- Adicionar Edição de Vinho
- Adicionar Vendedor
- Adicionar produto (Vinho vendido por um produtor)

### Menu Consultas
- Listar Países
- Listar Produtores
- Listar Regiões
- Listar Tipos de vinho
- Listar Edições de um vinho Vinho
- Listar todos os vinhos

- Listar Vinhhos de um país (solicitar código do país)
- Listar vinhos de uma região (Solicitar País e região)
- Listar vinhos de um produtor
- Listar vinhos de um tipo

### Menus Preços
- Adicionar preço de uma edição de vinho (produto vendido por um fornecedor)
- Lista de preços de uma edição de vinho (o Preço que cada vendedor pratica)

- Preço Médio que uma edição de vinho é vendida
- Vendedor que pratica o preço mais baixo de uma edição de vinho