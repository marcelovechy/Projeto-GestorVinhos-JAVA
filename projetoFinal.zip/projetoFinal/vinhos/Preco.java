package vinhos;

import java.time.LocalDate;

public class Preco {

    private int id;
    private double valor;
    private int eVinho;
    private LocalDate data;
    private int vendedor;
    private int produto;

    public Preco(int id, double valor, int eVinho, LocalDate data, int vendedor, int produto) {
        this.id = id;
        this.valor = valor;
        this.eVinho = eVinho;
        this.data = data;
        this.vendedor = vendedor;
        this.produto = produto;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValor() {
        return this.valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getEVinho() {
        return this.eVinho;
    }

    public void setEVinho(int eVinho) {
        this.eVinho = eVinho;
    }

    public LocalDate getData() {
        return this.data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public int getVendedor() {
        return this.vendedor;
    }

    public void setVendedor(int vendedor) {
        this.vendedor = vendedor;
    }

    public int getProduto() {
        return this.produto;
    }

    public void setProduto(int produto) {
        this.produto = produto;
    }

    @Override
    public String toString() {
        return "[" + this.id + "] " + "Edição de Vinho" + this.eVinho + " = " + this.valor;
    }
}