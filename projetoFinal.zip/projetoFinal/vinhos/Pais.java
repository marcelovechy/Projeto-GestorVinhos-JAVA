package vinhos;

import java.util.HashMap;

public class Pais {

    private int id;
    private String code;
    private String nome;
    private HashMap<Integer,Regiao> regioes;
    private HashMap<Integer,Vinho> vinhos;


    public Pais(int id, String code, String nome) {
        this.id = id;
        this.code = code;
        this.nome = nome;
        this.regioes=new HashMap<>();
        this.vinhos=new HashMap<>();
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "[" + this.code + "] " + this.nome;
    }

}