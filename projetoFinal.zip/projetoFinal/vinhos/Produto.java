package vinhos;

import java.util.Stack;

/**
 * Classe que representa um Produto. Um produto é uma ediçao de um vinho, vendido por uma loja
 */
public class Produto {

    private int id;
    private int vendedor;
    private int tipo;
    private String url;
    private String productCode;//Código do Produto da Loja, caso exista
    private Stack<Preco> precos; //Preços através de uma Pilha. Último preço é sempre o primeiro da pilha

    public Produto(int id, int vendedor, int tipo, String url) {
        this.id = id;
        this.vendedor = vendedor;
        this.tipo = tipo;
        this.url = url;
        this.precos=new Stack<>();
    }

    public Produto(int id, int vendedor, int tipo, String url, String productCode) {
        this.id = id;
        this.vendedor = vendedor;
        this.tipo = tipo;
        this.url = url;
        this.productCode = productCode;
        this.precos=new Stack<>();
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVendedor() {
        return this.vendedor;
    }

    public void setVendedor(int vendedor) {
        this.vendedor = vendedor;
    }

    public int getTipo() {
        return this.tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    @Override
    public String toString() {
        return "[" + this.id + "]" + this.url;
    }
    
}
