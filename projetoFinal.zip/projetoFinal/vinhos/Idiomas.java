package vinhos;

public enum Idiomas {
    PT,ENG;

}
