package vinhos;

import java.util.HashMap;

public class Vinho {

    private int id;
    private String nome;
    private int tipo;
    private int regiao;
    private int produtor;
    private String pais;
    private HashMap<Integer, EdicaoVinho> edicoes; //Edição por ano

    public Vinho(int id, String nome, int tipo, String pais, int regiao, int produtor) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.regiao = regiao;
        this.produtor = produtor;
        this.pais = pais;
        this.edicoes = new HashMap<>();
    }
    

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTipo() {
        return this.tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getRegiao() {
        return this.regiao;
    }

    public void setRegiao(int regiao) {
        this.regiao = regiao;
    }

    public int getProdutor() {
        return this.produtor;
    }

    public void setProdutor(int produtor) {
        this.produtor = produtor;
    }

    public String getPais() {
        return this.pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
    public String toString() {
        return "[" + this.id + "]" + this.nome;
    }
    
}