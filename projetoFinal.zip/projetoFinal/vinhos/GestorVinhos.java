package vinhos;

import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalDate;

public class GestorVinhos {

    // Adega

    public String nome;

    // Idioma

    private Idiomas idioma;

    public Idiomas getIdioma() {
        return this.idioma;
    }

    public void setIdioma(Idiomas idioma) {
        this.idioma = idioma;
    }

    // País

    private HashMap<String, Pais> dossierPais;
    public HashMap<String, Pais> PaisID;
    private int nextPais = 1;

    // Regiao

    private HashMap<String, Regiao> dossierRegiao;
    public HashMap<Integer, Regiao> RegiaoID;
    private int nextRegiao = 1;

    // Produtor

    private HashMap<String, Produtor> dossierProdutor;
    public HashMap<Integer, Produtor> ProdutorID;
    private int nextProdutor = 1;

    // Tipo de Vinho

    private HashMap<String, TipoVinho> dossierTipoVinho;
    public HashMap<Integer, TipoVinho> TipoVinhoID;
    private int nextTipoVinho = 1;

    // Vinho

    private HashMap<String, Vinho> dossierVinho;
    public HashMap<Integer, Vinho> VinhoID;
    private int nextVinho = 1;

    // Edição de Vinho

    private HashMap<Integer, EdicaoVinho> dossierEdicaoVinho;
    public HashMap<Integer, EdicaoVinho> EdicaoVinhoID;
    private int nextEdicaoVinho = 1;

    // Vendedor

    private HashMap<String, Vendedor> dossierVendedor;
    public HashMap<Integer, Vendedor> VendedorID;
    private int nextVendedor = 1;

    // Produto

    private HashMap<String, Produto> dossierProduto;
    public HashMap<Integer, Produto> ProdutoID;
    private int nextProduto = 1;

    // Preço

    private HashMap<Double, Preco> dossierPreco;
    public HashMap<Integer, Preco> PrecoID;
    private int nextPreco = 1;

    // Todos

    public GestorVinhos(String _nome) {

        this.idioma = Idiomas.PT;

        this.nome = _nome;

        this.dossierPais = new HashMap<>();
        this.PaisID = new HashMap<>();
        this.nextPais = 1;

        this.dossierRegiao = new HashMap<>();
        this.RegiaoID = new HashMap<>();
        this.nextRegiao = 1;

        this.dossierProdutor = new HashMap<>();
        this.ProdutorID = new HashMap<>();
        this.nextProdutor = 1;

        this.dossierTipoVinho = new HashMap<>();
        this.TipoVinhoID = new HashMap<>();
        this.nextTipoVinho = 1;

        this.dossierVinho = new HashMap<>();
        this.VinhoID = new HashMap<>();
        this.nextVinho = 1;

        this.dossierEdicaoVinho = new HashMap<>();
        this.EdicaoVinhoID = new HashMap<>();
        this.nextEdicaoVinho = 1;

        this.dossierVendedor = new HashMap<>();
        this.VendedorID = new HashMap<>();
        this.nextVendedor = 1;

        this.dossierProduto = new HashMap<>();
        this.ProdutoID = new HashMap<>();
        this.nextProduto = 1;

        this.dossierPreco = new HashMap<>();
        this.PrecoID = new HashMap<>();
        this.nextPreco = 1;
    }

    // Idioma

    /*
     * 1. O primeiro método, `escolherIdiomaPT()`, é um método que configura o campo
     * `idioma` para `Idiomas.PT`.
     * 2. O segundo método, `escolherIdiomaENG()`, é um método que define o campo
     * `idioma` para `Idiomas.ENG`.
     * 3. O terceiro método, `trocarIdioma()`, é um método que alterna o campo
     * `idioma` entre `Idiomas.PT` e `Idiomas.ENG`.
     */

    public boolean escolherIdiomaENG() {
        this.idioma = Idiomas.ENG;
        return true;
    }

    public boolean escolherIdiomaPT() {
        this.idioma = Idiomas.PT;
        return true;
    }

    public boolean trocarIdioma() {
        switch (this.idioma) {
            case PT:
                return this.escolherIdiomaENG();
            case ENG:
                return this.escolherIdiomaPT();
            default:
                return false;
        }

    }

    // País

    /**
     * @param id
     * @param code
     * @param nome
     */

    /*
     * 1. O método `criarPais` recebe dois parâmetros: `code` e `nome`.
     * 2. O método verifica se o `code` já existe no mapa `dossierPais`.
     * 3. Se o `code` já existir, o método retornará `false`.
     * 4. Se o `code` não existir, o método cria um novo objeto `Pais` e o atribui à
     * variável `pais`.
     * 5. O método então adiciona o objeto `pais` ao mapa `dossierPais`.
     * 6. O método também adiciona o `code` ao mapa `PaisID`.
     * 7. O método retorna `true` se o `code` não existir.
     */

    public boolean criarPais(String code, String nome) {
        if (this.dossierPais.containsKey(code))
            return false;
        Pais pais = new Pais(this.nextPais, code, nome);
        this.dossierPais.put(code, pais);
        this.PaisID.put(pais.getCode(), pais);
        this.nextPais++;
        return true;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo Pais.
     * 2. Ele itera através do PaisID HashMap e adiciona cada entrada ao ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<Pais> listarPais() {
        ArrayList<Pais> todosPais = new ArrayList<>(this.PaisID.values());
        return todosPais;
    }

    /**
     * 
     * @param code
     * @return true/false
     */

    /*
     * 1. O método PaisExiste() recebe um code String como parâmetro.
     * 2. Verifica se o code está no HashMap PaisID.
     * 3. Se o cóode estiver no HashMap, ele retornará true.
     * 4. Se o code não estiver no HashMap, ele retornará false.
     */
    public boolean PaisExiste(String code) {
        return this.PaisID.containsKey(code);
    }

    // Regiao

    /**
     * @param id
     * @param pais
     * @param nome
     */

    /*
     * 1. O método verifica se o país existe no mapa PaisID.
     * 2. Caso o país exista, verifica se a região existe no mapa do dossiêRegião.
     * 3. Se a região existir, ela retornará false.
     * 4. Caso a região não exista, cria um novo objeto Regiao e adiciona-o ao mapa
     * dossierRegiao.
     * 5. Ele também adiciona o novo objeto Regiao ao mapa RegiaoID.
     * 6. Incrementa a variável nextRegiao.
     * 7. Retorna verdadeiro.
     */

    public boolean criarRegiao(String pais, String nome) {
        if (this.PaisID.containsKey(pais)) {
            if (this.dossierRegiao.containsKey(nome)) {
                return false;
            }
            Regiao regiao = new Regiao(this.nextRegiao, nome);
            this.dossierRegiao.put(nome, regiao);
            this.RegiaoID.put(regiao.getId(), regiao);
            this.nextRegiao++;
            return true;
        }
        return false;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo Regiao.
     * 2. Ele itera através do RegiaoID HashMap e adiciona cada entrada ao
     * ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<Regiao> listarRegiao() {
        ArrayList<Regiao> todosRegiao = new ArrayList<>(this.RegiaoID.values());
        return todosRegiao;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método RegiaoExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap RegiaoID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean RegiaoExiste(int id) {
        return this.RegiaoID.containsKey(id);
    }

    // Produtor

    /**
     * @param id
     * @param nome
     */

    /*
     * 1. O método verifica se o Produtor já existe.
     * 2. Se isso acontecer, ele retornará false.
     * 3. Caso contrário, cria um novo objeto Produtor e o adiciona ao mapa do
     * dossiêProdutor.
     * 4. Também adiciona o ID do Produtor ao mapa do ProdutorID.
     * 5. Incrementa a variável nextProdutor.
     * 6. Retorna verdadeiro.
     */

    public boolean criarProdutor(String nome) {
        if (this.dossierProdutor.containsKey(nome))
            return false;
        Produtor produtor = new Produtor(this.nextProdutor, nome);
        this.dossierProdutor.put(nome, produtor);
        this.ProdutorID.put(produtor.getId(), produtor);
        this.nextProdutor++;
        return true;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo Produtor.
     * 2. Ele itera através do ProdutorID HashMap e adiciona cada entrada ao
     * ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<Produtor> listarProdutor() {
        ArrayList<Produtor> todosProdutor = new ArrayList<>(this.ProdutorID.values());
        return todosProdutor;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método ProdutorExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap ProdutorID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean ProdutorExiste(int id) {
        return this.ProdutorID.containsKey(id);
    }

    // Tipo de Vinho

    /**
     * @param id
     * @param nome
     */

    /*
     * 1. O método verifica se o nome já existe no HashMap.
     * 2. Se isso acontecer, ele retornará false.
     * 3. Caso contrário, cria um novo objeto TipoVinho e adiciona-o ao HashMap.
     * 4. Também adiciona o objeto TipoVinho ao HashMap TipoVinhoID.
     * 5. Incrementa a variável nextTipoVinho.
     * 6. Retorna verdadeiro.
     */

    public boolean criarTipoVinho(String nome) {
        if (this.dossierTipoVinho.containsKey(nome))
            return false;
        TipoVinho tipovinho = new TipoVinho(this.nextTipoVinho, nome);
        this.dossierTipoVinho.put(nome, tipovinho);
        this.TipoVinhoID.put(tipovinho.getId(), tipovinho);
        this.nextTipoVinho++;
        return true;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo TipoVinho.
     * 2. Ele itera através do TipoVinhoID HashMap e adiciona cada entrada ao
     * ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<TipoVinho> listarTipoVinho() {
        ArrayList<TipoVinho> todosTipoVinho = new ArrayList<>(this.TipoVinhoID.values());
        return todosTipoVinho;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método TipoVinhoExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap TipoVinhoID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean TipoVinhoExiste(int id) {
        return this.TipoVinhoID.containsKey(id);
    }

    // Vinho

    /**
     * @param id
     * @param nome_vinho
     * @param tipoVinho
     * @param cod_pais
     * @param id_regiao
     * @param id_produtor
     */

    /*
     * 1. O método verifica se o passado em tipoVinho está no mapa TipoVinhoID.
     * 2. Se estiver, verifica se o passado em cod_pais está no mapa PaisID.
     * 3. Se estiver, verifica se o passado em id_regiao está no mapa RegiaoID.
     * 4. Se estiver, verifica se o passado em id_produtor está no mapa ProdutorID.
     * 5. Se estiver, verifica se o passado em nome_vinho está no mapa dossierVinho.
     * 6. Se for, retorna falso.
     * 7. Se não estiver, cria um novo objeto Vinho e adiciona-o ao mapa
     * dossierVinho.
     * 8. Em seguida, ele retorna verdadeiro.
     */

    public boolean criarVinho(String nome_vinho, int tipoVinho, String cod_pais, int id_regiao, int id_produtor) {
        if (this.TipoVinhoID.containsKey(tipoVinho)) {
            if (this.PaisID.containsKey(cod_pais)) {
                if (this.RegiaoID.containsKey(id_regiao)) {
                    if (this.ProdutorID.containsKey(id_produtor)) {
                        if (this.dossierVinho.containsKey(nome_vinho)) {
                            return false;
                        }
                        Vinho vinho = new Vinho(this.nextVinho, nome_vinho, tipoVinho, cod_pais, id_regiao,
                                id_produtor);
                        this.dossierVinho.put(nome_vinho, vinho);
                        this.VinhoID.put(vinho.getId(), vinho);
                        this.nextVinho++;
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return false;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo Vinho.
     * 2. Ele itera através do VinhoID HashMap e adiciona cada entrada ao
     * ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<Vinho> listarVinho() {
        ArrayList<Vinho> todosVinho = new ArrayList<>(this.VinhoID.values());
        return todosVinho;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método VinhoExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap VinhoID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean VinhoExiste(int id) {
        return this.VinhoID.containsKey(id);
    }

    // Edição de Vinho

    /**
     * @param id
     * @param vinho
     * @param ano
     */

    /*
     * 1. O método verifica se o ID do vinho está no mapa de hash.
     * 2. Se o ID do vinho estiver no mapa de hash, ele verifica se o ano está no
     * mapa de hash.
     * 3. Se o ano estiver no mapa de hash, ele retornará false.
     * 4. Caso o ano não esteja no mapa de hash, cria um novo objeto EdicaoVinho e
     * adiciona-o ao mapa de hash.
     * 5. Retorna verdadeiro.
     */

    public boolean criarEdicaoVinho(int vinho, int ano) {
        if (this.VinhoID.containsKey(vinho)) {
            if (this.dossierEdicaoVinho.containsKey(ano)) {
                return false;
            }
            EdicaoVinho edicaovinho = new EdicaoVinho(this.nextEdicaoVinho, vinho, ano);
            this.dossierEdicaoVinho.put(ano, edicaovinho);
            this.EdicaoVinhoID.put(edicaovinho.getId(), edicaovinho);
            this.nextEdicaoVinho++;
            return true;
        }
        return false;
    }

    /**
     * 
     * @return
     */

    /*
     * 1. Cria um ArrayList do tipo EdicaoVinho.
     * 2. Ele itera através do EdicaoVinhoID HashMap e adiciona cada entrada ao
     * ArrayList.
     * 3. Retorna o ArrayList.
     */

    public ArrayList<EdicaoVinho> listarEdicaoVinho() {
        ArrayList<EdicaoVinho> todosEdicaoVinho = new ArrayList<>(this.EdicaoVinhoID.values());
        return todosEdicaoVinho;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método EdicaoinhoExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap EdicaoVinhoID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean EdicaoVinhoExiste(int id) {
        return this.EdicaoVinhoID.containsKey(id);
    }

    // Vendedor

    /**
     * @param id
     * @param nome
     */

    /*
     * 1. O método verifica se o nome já está no mapa. Se for, retorna falso.
     * 2. Caso o nome não esteja no mapa, ele cria um novo objeto Vendedor e o
     * adiciona ao mapa.
     * 3. Também adiciona o objeto Vendedor ao mapa VendedorID.
     * 4. Incrementa a variável nextVendedor.
     * 5. Retorna verdadeiro.
     */

    public boolean criarVendedor(String nome) {
        if (this.dossierVendedor.containsKey(nome))
            return false;
        Vendedor vendedor = new Vendedor(this.nextVendedor, nome);
        this.dossierVendedor.put(nome, vendedor);
        this.VendedorID.put(vendedor.getId(), vendedor);
        this.nextVendedor++;
        return true;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método VendedorExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap VendedorID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean VendedorExiste(int id) {
        return this.VendedorID.containsKey(id);
    }

    // Produto

    /**
     * @param id
     * @param vendedor
     * @param tipo
     * @param url
     * @param productCode
     */

    /*
     * 1. O método verifica se o vendedor e o tipo são válidos.
     * 2. Se estiverem, cria um novo objeto Produto e o adiciona ao mapa
     * dossierProduto.
     * 3. Também adiciona o objeto Produto ao mapa ProdutoID.
     * 4. Retorna verdadeiro se o objeto Produto foi criado, caso contrário retorna
     * falso.
     */

    public boolean criarProduto(int vendedor, int tipo, String url, String productCode) {
        if (this.VendedorID.containsKey(vendedor)) {
            if (this.TipoVinhoID.containsKey(tipo)) {
                if (this.dossierProduto.containsKey(url)) {
                    return false;
                }
                Produto produto = new Produto(this.nextProduto, vendedor, tipo, url, productCode);
                this.dossierProduto.put(url, produto);
                this.ProdutoID.put(produto.getId(), produto);
                this.nextProduto++;
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * 
     * @param id
     * @return true/false
     */

    /*
     * 1. O método ProdutoExiste() recebe um id inteiro como parâmetro.
     * 2. Verifica se o id está no hashmap ProdutoID.
     * 3. Se for, retorna verdadeiro.
     * 4. Se não for, retorna false.
     */

    public boolean ProdutoExiste(int id) {
        return this.ProdutoID.containsKey(id);
    }

    // Preco

    /**
     * @param id
     * @param valor
     * @param eVinho
     * @param data
     * @param vendedor
     * @param produto
     */

    /*
     * 1. O método verifica se o ID da edição do vinho está no mapa.
     * 2. Se estiver, verifica se o ID do vendedor está no mapa.
     * 3. Se estiver, verifica se o ID do produto está no mapa.
     * 4. Se estiver, verifica se o preço está no mapa.
     * 5. Se for, retorna falso.
     * 6. Se não estiver, ele cria um novo objeto Preco e o adiciona ao mapa.
     * 7. Retorna verdadeiro.
     */

    public boolean criarPreco(double valor, int eVinho, LocalDate data, int vendedor, int produto) {
        if (this.EdicaoVinhoID.containsKey(eVinho)) {
            if (this.VendedorID.containsKey(vendedor)) {
                if (this.ProdutoID.containsKey(produto)) {
                    if (this.dossierPreco.containsKey(valor)) {
                        return false;
                    }
                    Preco preco = new Preco(this.nextPreco, valor, eVinho, data, vendedor, produto);
                    this.dossierPreco.put(valor, preco);
                    this.PrecoID.put(preco.getId(), preco);
                    this.nextPreco++;
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }

}