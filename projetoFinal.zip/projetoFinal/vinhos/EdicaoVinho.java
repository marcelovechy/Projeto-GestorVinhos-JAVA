package vinhos;

import java.util.HashMap;

public class EdicaoVinho {

    private int id;
    private int vinho;
    private int ano;
    private HashMap<Vendedor, Produto> vendidoPor;
    private double precoMedio; // Média do preço atual (mais recente que cada produto)

    public EdicaoVinho(int id, int vinho, int ano) {
        this.id = id;
        this.vinho = vinho;
        this.ano = ano;
        this.precoMedio = 0.0;
        this.vendidoPor = new HashMap<>();
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVinho() {
        return this.vinho;
    }

    public void setVinho(int vinho) {
        this.vinho = vinho;
    }

    public int getAno() {
        return this.ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
      
    @Override
    public String toString() {
        return "[" + this.id + "] " + this.ano;
    }
}
