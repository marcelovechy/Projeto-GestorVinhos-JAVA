package vinhos;

import java.util.HashMap;

public class Regiao {

    private int id;
    private String nome;
    private HashMap<Integer,Vinho> vinhos;

    public Regiao(int id, String nome) {
        this.id = id;
        this.nome = nome;
        this.vinhos=new HashMap<>();
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    @Override
    public String toString() {
        return "[" + this.id + "] " + this.nome;
    }
}