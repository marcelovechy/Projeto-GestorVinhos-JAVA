package app.prices;

import vinhos.GestorVinhos;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.LerInteiro;
import ui.LerDouble;
import ui.LerData;
import ui.exceptions.DialogException;

public class DoAddWineEditionPrice extends Comando<GestorVinhos> {

    private LerDouble valor;
    private LerInteiro eVinho;
    private LerData data;
    private LerInteiro vendedor;
    private LerInteiro produto;

    public DoAddWineEditionPrice(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.valor = new LerDouble(GestorIdiomas.getASK_PRICE_VALUE(receptor.getIdioma()));
        this.eVinho = new LerInteiro(GestorIdiomas.getASK_WINE_EDITION_ID(receptor.getIdioma()));
        this.data = new LerData(GestorIdiomas.getASK_PRICE_DATA(receptor.getIdioma()));
        this.vendedor = new LerInteiro(GestorIdiomas.getASK_SELLER_ID(receptor.getIdioma()));
        this.produto = new LerInteiro(GestorIdiomas.getASK_PRODUCT_ID(receptor.getIdioma()));
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ui.lerInput(this.valor);
        ui.lerInput(this.eVinho);
        ui.lerInput(this.data);
        ui.lerInput(this.vendedor);
        ui.lerInput(this.produto);

        boolean result = this.getReceptor().criarPreco(valor.getValor(), eVinho.getValor(), data.getValor(), vendedor.getValor(), produto.getValor());

        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getprice_success(receptor.getIdioma(), this.valor.getValor()));
        } 
        else if(!this.getReceptor().EdicaoVinhoExiste(this.eVinho.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getwine_edition_no_exist(receptor.getIdioma(), this.eVinho.getValor()));
        }
        else if(!this.getReceptor().VendedorExiste(this.vendedor.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getseller_no_exist(receptor.getIdioma(), this.vendedor.getValor()));
        }
        else if(!this.getReceptor().ProdutoExiste(this.produto.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getproduct_no_exist(receptor.getIdioma(), this.produto.getValor()));
        }
        else {
            this.ui.escreveLinha(GestorIdiomas.getprice_error(receptor.getIdioma(),this.produto.getValor(), this.valor.getValor()));
        }
    }
}
