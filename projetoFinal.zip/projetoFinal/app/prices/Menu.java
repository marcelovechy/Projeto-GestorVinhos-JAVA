package app.prices;

import vinhos.GestorVinhos;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.exceptions.DialogException;

public class Menu extends ui.Menu{

    public Menu(GestorVinhos vinhos) {
       super(GestorIdiomas.getMENU_PRECOS(vinhos.getIdioma()), new Comando<?>[]{
            new DoAddWineEditionPrice(vinhos, GestorIdiomas.getADD_PRICE(vinhos.getIdioma()))
        
        });
    }
    
}
