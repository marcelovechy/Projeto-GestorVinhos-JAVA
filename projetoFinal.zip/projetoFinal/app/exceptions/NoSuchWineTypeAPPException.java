package app.exceptions;

import ui.exceptions.DialogException;

public class NoSuchWineTypeAPPException extends DialogException{
    private int id;

    public NoSuchWineTypeAPPException(int id) {
        this.id = id;
    }

    @Override
    public String getMessage() {
        return "ERRO! Tipo de Vinho com o id "+this.id+" não existe!";
    }
}
