package app.exceptions;

import ui.exceptions.DialogException;

public class NoSuchProducerAPPException extends DialogException{

    private int id;

    public NoSuchProducerAPPException(int id) {
        this.id = id;
    }
    
    @Override
    public String getMessage() {
        return "ERRO! Produtor com o id "+this.id+" não existe!";
    }
    
}
