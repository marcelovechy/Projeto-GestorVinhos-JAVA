package app.exceptions;

import ui.exceptions.DialogException;

public class CountryDoesNotExistsAPPException extends DialogException{
    private String pais;

    public CountryDoesNotExistsAPPException(String pais) {
        this.pais = pais;
    }

    @Override
    public String getMessage() {
        return "O país com o código "+this.pais+" não existe!";
    }
    
}
