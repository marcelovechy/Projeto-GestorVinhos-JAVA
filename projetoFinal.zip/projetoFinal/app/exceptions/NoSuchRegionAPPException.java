package app.exceptions;

import ui.exceptions.DialogException;

public class NoSuchRegionAPPException extends DialogException {
    private int id;

    public NoSuchRegionAPPException(int id) {
        this.id = id;
    }

    @Override
    public String getMessage() {
        return "ERRO! Região com o id "+this.id+" não existe!";
    }
}
