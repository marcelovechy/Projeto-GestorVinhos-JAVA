package app.exceptions;

import ui.exceptions.DialogException;

public class WineEditionAlreadyExistsAPPException extends DialogException{

    private int ano;
    private int vinho_id;


    public WineEditionAlreadyExistsAPPException(int ano, int vinho_id) {
        this.ano = ano;
        this.vinho_id = vinho_id;
    }

    @Override
    public String getMessage() {
        return "ERRO! Edição de "+this.ano+" já existe para o vinho ID="+this.vinho_id;
    }
    
}
