package app.exceptions;

import ui.exceptions.DialogException;

public class CountryAlreadyExistsAPPException extends DialogException {

    private String code;


    public CountryAlreadyExistsAPPException(String code) {
        this.code = code;
    }    


    @Override
    public String getMessage() {
        return "Já existe o país com o código "+this.code;
    }

    
}
