package app;

import vinhos.GestorVinhos;
import app.main.Menu;


public class App {

    public static void main(String[] args) {
        
        GestorVinhos adega = new GestorVinhos("Adega");
 
        Menu m = new Menu(adega);
        m.open();
    }    
}
