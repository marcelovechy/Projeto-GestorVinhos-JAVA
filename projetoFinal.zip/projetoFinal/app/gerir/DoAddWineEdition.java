package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.LerInteiro;
import ui.exceptions.DialogException;

public class DoAddWineEdition extends Comando<GestorVinhos> {

    private LerInteiro vinho;
    private LerInteiro ano;

    public DoAddWineEdition(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.vinho = new LerInteiro(GestorIdiomas.getASK_WINE_ID(receptor.getIdioma()));
        this.ano = new LerInteiro(GestorIdiomas.getASK_WINE_EDITION_YEAR(receptor.getIdioma()));
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ui.lerInput(this.vinho);
        ui.lerInput(this.ano);
        
        boolean result = this.getReceptor().criarEdicaoVinho(vinho.getValor(), ano.getValor());

        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getwine_edition_success(receptor.getIdioma(), this.ano.getValor(), this.vinho.getValor()));
        } 
        else if(!this.getReceptor().VinhoExiste(this.vinho.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getwine_no_exist(receptor.getIdioma(), this.vinho.getValor()));
        }
        else {
            this.ui.escreveLinha(GestorIdiomas.getwine_edition_error(receptor.getIdioma(), this.ano.getValor(), this.vinho.getValor()));
        }
    }

}
