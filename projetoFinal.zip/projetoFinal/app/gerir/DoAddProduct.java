package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.LerInteiro;
import ui.exceptions.DialogException;

public class DoAddProduct extends Comando<GestorVinhos> {

    private LerInteiro vendedor;
    private LerInteiro tipo;
    private LerString url;
    private LerString productCode;

    public DoAddProduct(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.vendedor = new LerInteiro(GestorIdiomas.getASK_SELLER_ID(receptor.getIdioma()));
        this.tipo = new LerInteiro(GestorIdiomas.getASK_WINE_TYPE_ID(receptor.getIdioma()));
        this.url = new LerString(GestorIdiomas.getASK_PRODUCT_URL(receptor.getIdioma()), "((http|https)://)(www.)?"
                + "[a-zA-Z0-9@:%._\\+~#?&//=]"
                + "{2,256}\\.[a-z]"
                + "{2,6}\\b([-a-zA-Z0-9@:%"
                + "._\\+~#?&//=]*)");
        this.productCode = new LerString(GestorIdiomas.getASK_PRODUCT_CODE(receptor.getIdioma()), null);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ui.lerInput(this.vendedor);
        ui.lerInput(this.tipo);
        ui.lerInput(this.url);
        ui.lerInput(this.productCode);

        boolean result = this.getReceptor().criarProduto(vendedor.getValor(), tipo.getValor(), url.getValor(),
                productCode.getValor());

        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getproduct_success(receptor.getIdioma(), this.url.getValor()));
        } else if (!this.getReceptor().VendedorExiste(this.vendedor.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getseller_no_exist(receptor.getIdioma(), this.vendedor.getValor()));
        } else {
            this.ui.escreveLinha(GestorIdiomas.getproduct_error(receptor.getIdioma(), this.url.getValor()));
        }
    }
}
