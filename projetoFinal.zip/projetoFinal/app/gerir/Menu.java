package app.gerir;

import vinhos.GestorVinhos;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.exceptions.DialogException;

public class Menu extends ui.Menu{

    public Menu(GestorVinhos vinhos) {
       super(GestorIdiomas.getMENU_GERIR(vinhos.getIdioma()), new Comando<?>[]{
            new DoAddCountry(vinhos, GestorIdiomas.getADD_COUNTRY(vinhos.getIdioma())),
            new DoAddRegion(vinhos, GestorIdiomas.getADD_REGION(vinhos.getIdioma())),
            new DoAddProducer(vinhos, GestorIdiomas.getADD_PRODUCER(vinhos.getIdioma())),
            new DoAddWineType(vinhos, GestorIdiomas.getADD_WINE_TYPE(vinhos.getIdioma())),
            new DoAddWine(vinhos, GestorIdiomas.getADD_WINE(vinhos.getIdioma())),
            new DoAddWineEdition(vinhos, GestorIdiomas.getADD_WINE_EDITION(vinhos.getIdioma())),
            new DoAddSeller(vinhos, GestorIdiomas.getADD_SELLER(vinhos.getIdioma())),
            new DoAddProduct(vinhos, GestorIdiomas.getADD_PRODUCT(vinhos.getIdioma()))

        });
    }
    
}
