package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.exceptions.DialogException;

public class DoAddProducer extends Comando<GestorVinhos> {

    private LerString nome;

    public DoAddProducer(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.nome=new LerString(GestorIdiomas.getASK_PRODUCER_NAME(receptor.getIdioma()), null);
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        this.ui.lerInput(this.nome);

        boolean result = this.getReceptor().criarProdutor(nome.getValor());
        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getproducer_success(receptor.getIdioma(), this.nome.getValor()));
        } else
            this.ui.escreveLinha(GestorIdiomas.getproducer_error(receptor.getIdioma(), this.nome.getValor()));
    }

    
}