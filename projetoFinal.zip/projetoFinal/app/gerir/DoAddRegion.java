package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.exceptions.DialogException;

public class DoAddRegion extends Comando<GestorVinhos> {

    private LerString pais;
    private LerString nome;

    public DoAddRegion(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.pais = new LerString(GestorIdiomas.getASK_COUNTRY_CODE(receptor.getIdioma()), null);
        this.nome = new LerString(GestorIdiomas.getASK_REGION_NAME(receptor.getIdioma()), null);
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        this.ui.lerInput(this.pais);
        this.ui.lerInput(this.nome);

        boolean result = this.getReceptor().criarRegiao(pais.getValor(), nome.getValor());

        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getregion_success(receptor.getIdioma(), this.nome.getValor()));
        } 
        else if(!this.getReceptor().PaisExiste(this.pais.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getcountry_no_exist(receptor.getIdioma(), this.pais.getValor()));
        }
        else {
            this.ui.escreveLinha(GestorIdiomas.getregion_error(receptor.getIdioma(),this.nome.getValor()));
        }
    }
}