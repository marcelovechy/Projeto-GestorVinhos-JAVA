package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.exceptions.DialogException;

public class DoAddSeller extends Comando<GestorVinhos> {
    
    private LerString nome;

    public DoAddSeller(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.nome = new LerString(GestorIdiomas.getASK_SELLER_NAME(receptor.getIdioma()), null);
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        this.ui.lerInput(this.nome);
        
        boolean result = this.getReceptor().criarVendedor(nome.getValor());
        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getseller_success(receptor.getIdioma(), this.nome.getValor()));
        } else
            this.ui.escreveLinha(GestorIdiomas.getseller_error(receptor.getIdioma(), this.nome.getValor()));
    }
}
