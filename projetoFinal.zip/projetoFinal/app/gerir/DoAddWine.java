package app.gerir;

import vinhos.GestorVinhos;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.Constantes;
import ui.LerString;
import ui.LerInteiro;
import ui.exceptions.DialogException;

public class DoAddWine extends Comando<GestorVinhos> {

    private LerString nome_vinho;
    private LerInteiro tipoVinho;
    private LerString cod_pais;
    private LerInteiro id_regiao;
    private LerInteiro id_produtor;

    public DoAddWine(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

        this.nome_vinho = new LerString(GestorIdiomas.getASK_WINE_NAME(receptor.getIdioma()), null);
        this.tipoVinho = new LerInteiro(GestorIdiomas.getASK_WINE_TYPE_ID(receptor.getIdioma()));
        this.cod_pais = new LerString(GestorIdiomas.getASK_COUNTRY_CODE(receptor.getIdioma()), null);
        this.id_regiao = new LerInteiro(GestorIdiomas.getASK_REGION_ID(receptor.getIdioma()));
        this.id_produtor = new LerInteiro(GestorIdiomas.getASK_PRODUCER_ID(receptor.getIdioma()));
    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ui.lerInput(this.nome_vinho);
        ui.lerInput(this.tipoVinho);
        ui.lerInput(this.cod_pais);
        ui.lerInput(this.id_regiao);
        ui.lerInput(this.id_produtor);

        boolean result = this.getReceptor().criarVinho(nome_vinho.getValor(), tipoVinho.getValor(), cod_pais.getValor(), id_regiao.getValor(), id_produtor.getValor());

        if (result) {
            this.ui.escreveLinha(GestorIdiomas.getwine_success(receptor.getIdioma(), this.nome_vinho.getValor()));
        } 
        else if(!this.getReceptor().TipoVinhoExiste(this.tipoVinho.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getwine_type_no_exist(receptor.getIdioma(), this.tipoVinho.getValor()));
        }
        else if(!this.getReceptor().PaisExiste(this.cod_pais.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getcountry_no_exist(receptor.getIdioma(), this.cod_pais.getValor()));
        }
        else if(!this.getReceptor().RegiaoExiste(this.id_regiao.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getregion_no_exist(receptor.getIdioma(), this.id_regiao.getValor()));
        }
        else if(!this.getReceptor().ProdutorExiste(this.id_produtor.getValor())) {
            this.ui.escreveLinha(GestorIdiomas.getproducer_no_exist(receptor.getIdioma(), this.id_produtor.getValor()));
        }
        else {
            this.ui.escreveLinha(GestorIdiomas.getwine_error(receptor.getIdioma(),this.nome_vinho.getValor()));
        }
    }
}
