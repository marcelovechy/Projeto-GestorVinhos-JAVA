package app.idiomas;

public class ENG {

    // Menu Principal
    public static String MenuPrincipal="Main menu";
    public static String EscolherIdioma = "Mudar para Português";
    public static String OpenMenuGerir = "Open Menu Manage Wines";
    public static String OpenMenuConsultas = "Open Queries Menu";
    public static String OpenMenuAtualizar = "Open Prices Menu";
    public static String SaveApp = "Save Application";
    public static String LoadApp = "Upload File";

    // Menu Gerir
    public static String MENU_GERIR = "Wine Management Menu";
    public static String ADD_COUNTRY = "Add Country";
    public static String ADD_REGION = "Add Production Region";
    public static String ADD_PRODUCER = "Add Producer";
    public static String ADD_WINE_TYPE = "Add Wine Type";
    public static String ADD_WINE = "Add Wine";
    public static String ADD_WINE_EDITION = "Add Wine Edition";
    public static String ADD_SELLER = "Add Seller";
    public static String ADD_PRODUCT = "Add Product";

    // Menu CONSULTAS
    public static String MENU_CONSULTAS = "Queries Menu";
    public static String LIST_COUNTRY = "List Countries";
    public static String LIST_REGION = "List Regions";
    public static String LIST_PRODUCER = "List Producers";
    public static String LIST_WINE_TYPE = "List Type of Wine";
    public static String LIST_WINE = "List Wines";
    public static String LIST_WINE_EDITION = "Add Wine Edition";
    public static String LIST_WINE_COUNTRY = "List Wines of a Country";

    // Menu PRICES
    public static String MENU_PRECOS = "Prices Menu";
    public static String ADD_PRICE = "Add Price";

    /// Country
    public static String ASK_COUNTRY_NAME = "Enter country name: ";
    public static String ASK_COUNTRY_CODE = "Enter country code: ";
    public static String country_success(String code) {
        return "Country [" + code + "] successfully added";
    }
    public static String country_error(String code) {
        return "Country [" + code + "] already exists";
    }
    public static String country_no_exist(String code) {
        return "Country [" + code + "] does not exist";
    }

    /// Region 
    public static String ASK_REGION_NAME = "Enter the Region name: ";
    public static String ASK_REGION_ID = "Enter Region ID: ";
    public static String region_success(String nome) {
        return "Region [" + nome + "] successfully added";
    }
    public static String region_error(String nome) {
        return "Region [" + nome + "] already exists";
    }
    public static String region_no_exist(int id) {
        return "Region [" + id + "] does not exist";
    }

    /// Producer
    public static String ASK_PRODUCER_NAME = "Enter producer name: ";
    public static String ASK_PRODUCER_ID = "Enter producer ID: ";
    public static String producer_success(String nome) {
        return "Producer [" + nome + "] successfully added";
    }
    public static String producer_error(String nome) {
        return "Producer [" + nome + "] already exists";
    }
    public static String producer_no_exist(int id) {
        return "Producer [" + id + "] does not exist";
    }

    /// Wine Type 
    public static String ASK_WINE_TYPE_NAME = "Enter the type of wine: ";
    public static String ASK_WINE_TYPE_ID = "Enter the Wine Type ID: ";
    public static String wine_type_success(String nome) {
        return "Type of wine [" + nome + "] successfully added";
    }
    public static String wine_type_error(String nome) {
        return "Type of wine [" + nome + "] already exists";
    }
    public static String wine_type_no_exist(int id) {
        return "Type of wine [" + id + "] does not exist";
    }

    /// Wine
    public static String ASK_WINE_NAME = "Enter the wine name: ";
    public static String ASK_WINE_ID = "Enter wine ID: ";
    public static String wine_success(String nome) {
        return "Wine [" + nome + "] successfully added";
    }
    public static String wine_error(String nome) {
        return "Wine [" + nome + "] already exists";
    }
    public static String wine_no_exist(int id) {
        return "Wine [" + id + "] does not exist";
    }

    /// Wine Edition
    public static String ASK_WINE_EDITION_ID = "Enter the Year of Edition ID: ";
    public static String ASK_WINE_EDITION_YEAR = "Enter the Year of Edition: ";
    public static String wine_edition_success(int ano, int vinho) {
        return "Edition ["+ ano +"] of Wine with ID [" + vinho+ "] successfully added";
    }
    public static String wine_edition_error(int ano, int vinho) {
        return "Edition ["+ ano +"] of Wine with ID [" + vinho+ "] already exists";
    }
    public static String wine_edition_no_exist(int vinho) {
        return "Edition of Wine with ID [" + vinho+ "] does not exist";
    }

    /// Seller
    public static String ASK_SELLER_NAME = "Enter Seller name: ";
    public static String ASK_SELLER_ID = "Enter Seller ID: ";
    public static String seller_success(String nome) {
        return "Seller [" + nome + "] successfully added";
    }
    public static String seller_error(String nome) {
        return "Seller [" + nome + "] already exists";
    }
    public static String seller_no_exist(int id) {
        return "Seller [" + id + "] does not exist";
    }

    /// Product 
    public static String ASK_PRODUCT_URL = "Enter URL String: ";
    public static String ASK_PRODUCT_CODE = "Enter Product code: ";
    public static String ASK_PRODUCT_ID = "Enter Product ID: ";
    public static String product_success(String url) {
        return "Product [" + url + "] successfully added";
    }
    public static String product_error(String url) {
        return "Product [" + url + "] already exists";
    }
    public static String product_no_exist(int id) {
        return "Product [" + id + "] does not exist";
    }

    /// Price 
    public static String ASK_PRICE_VALUE = "Enter the Product price: ";
    public static String ASK_PRICE_DATA = "Enter the date: ";
    public static String price_success(double valor) {
        return "Product with price [" + valor + "] successfully added";
    }
    public static String price_error(int produto, double valor) {
        return "Product with ID [" + produto + "] and with price [" + valor + "] already exists";
    }
    
}
