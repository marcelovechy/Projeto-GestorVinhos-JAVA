package app.idiomas;

import vinhos.Idiomas;

public class GestorIdiomas {

    // Main Menu
    public static String getMenuPrincipal(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.MenuPrincipal;
            case ENG:
                return ENG.MenuPrincipal;
            default:
                return PT.MenuPrincipal;
        }
    }

    public static String getEscolherIdioma(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.EscolherIdioma;
            case ENG:
                return ENG.EscolherIdioma;
            default:
                return PT.EscolherIdioma;
        }
    }

    public static String getOpenMenuGerir(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.OpenMenuGerir;
            case ENG:
                return ENG.OpenMenuGerir;
            default:
                return PT.OpenMenuGerir;
        }
    }

    public static String getOpenMenuConsultas(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.OpenMenuConsultas;
            case ENG:
                return ENG.OpenMenuConsultas;
            default:
                return PT.OpenMenuConsultas;
        }
    }

    public static String getOpenMenuAtualizar(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.OpenMenuAtualizar;
            case ENG:
                return ENG.OpenMenuAtualizar;
            default:
                return PT.OpenMenuAtualizar;
        }
    }

    public static String getSaveApp(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.SaveApp;
            case ENG:
                return ENG.SaveApp;
            default:
                return PT.SaveApp;
        }
    }

    public static String getLoadApp(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LoadApp;
            case ENG:
                return ENG.LoadApp;
            default:
                return PT.LoadApp;
        }
    }

    public static String getLIST_WINE_COUNTRY(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_WINE_COUNTRY;
            case ENG:
                return ENG.LIST_WINE_COUNTRY;
            default:
                return PT.LIST_WINE_COUNTRY;
        }
    }

    // Gerir
    public static String getMENU_GERIR(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.MENU_GERIR;
            case ENG:
                return ENG.MENU_GERIR;
            default:
                return PT.MENU_GERIR;
        }
    }

    public static String getMENU_CONSULTAS(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.MENU_CONSULTAS;
            case ENG:
                return ENG.MENU_CONSULTAS;
            default:
                return PT.MENU_CONSULTAS;
        }
    }

    public static String getMENU_PRECOS(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.MENU_PRECOS;
            case ENG:
                return ENG.MENU_PRECOS;
            default:
                return PT.MENU_PRECOS;
        }
    }

    public static String getADD_COUNTRY(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_COUNTRY;
            case ENG:
                return ENG.ADD_COUNTRY;
            default:
                return PT.ADD_COUNTRY;
        }
    }

    public static String getADD_REGION(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_REGION;
            case ENG:
                return ENG.ADD_REGION;
            default:
                return PT.ADD_REGION;
        }
    }

    public static String getADD_PRODUCER(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_PRODUCER;
            case ENG:
                return ENG.ADD_PRODUCER;
            default:
                return PT.ADD_PRODUCER;
        }
    }

    public static String getADD_WINE_TYPE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_WINE_TYPE;
            case ENG:
                return ENG.ADD_WINE_TYPE;
            default:
                return PT.ADD_WINE_TYPE;
        }
    }

    public static String getADD_WINE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_WINE;
            case ENG:
                return ENG.ADD_WINE;
            default:
                return PT.ADD_WINE;
        }
    }

    public static String getADD_WINE_EDITION(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_WINE_EDITION;
            case ENG:
                return ENG.ADD_WINE_EDITION;
            default:
                return PT.ADD_WINE_EDITION;
        }
    }

    public static String getADD_SELLER(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_SELLER;
            case ENG:
                return ENG.ADD_SELLER;
            default:
                return PT.ADD_SELLER;
        }
    }

    public static String getADD_PRODUCT(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_PRODUCT;
            case ENG:
                return ENG.ADD_PRODUCT;
            default:
                return PT.ADD_PRODUCT;
        }
    }

    /// Prices
    public static String getADD_PRICE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ADD_PRICE;
            case ENG:
                return ENG.ADD_PRICE;
            default:
                return PT.ADD_PRICE;
        }
    }

    public static String getASK_PRICE_VALUE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRICE_VALUE;
            case ENG:
                return ENG.ASK_PRICE_VALUE;
            default:
                return PT.ASK_PRICE_VALUE;
        }
    }

    public static String getASK_PRICE_DATA(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRICE_DATA;
            case ENG:
                return ENG.ASK_PRICE_DATA;
            default:
                return PT.ASK_PRICE_DATA;
        }
    }

    public static String getprice_success(Idiomas idioma, double valor) {
        switch (idioma) {
            case PT:
                return PT.price_success(valor);
            case ENG:
                return ENG.price_success(valor);
            default:
                return PT.price_success(valor);
        }
    }

    public static String getprice_error(Idiomas idioma, int produto, double valor) {
        switch (idioma) {
            case PT:
                return PT.price_error(produto, valor);
            case ENG:
                return ENG.price_error(produto, valor);
            default:
                return PT.price_error(produto, valor);
        }
    }

    /// Country
    public static String getASK_COUNTRY_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_COUNTRY_NAME;
            case ENG:
                return ENG.ASK_COUNTRY_NAME;
            default:
                return PT.ASK_COUNTRY_NAME;
        }
    }

    public static String getASK_COUNTRY_CODE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_COUNTRY_CODE;
            case ENG:
                return ENG.ASK_COUNTRY_CODE;
            default:
                return PT.ASK_COUNTRY_CODE;
        }
    }

    public static String getcountry_success(Idiomas idioma, String code) {
        switch (idioma) {
            case PT:
                return PT.country_success(code);
            case ENG:
                return ENG.country_success(code);
            default:
                return PT.country_success(code);
        }
    }

    public static String getcountry_error(Idiomas idioma, String code) {
        switch (idioma) {
            case PT:
                return PT.country_error(code);
            case ENG:
                return ENG.country_error(code);
            default:
                return PT.country_error(code);
        }
    }

    public static String getcountry_no_exist(Idiomas idioma, String code) {
        switch (idioma) {
            case PT:
                return PT.country_no_exist(code);
            case ENG:
                return ENG.country_no_exist(code);
            default:
                return PT.country_no_exist(code);
        }

    }

    public static String getLIST_COUNTRY(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_COUNTRY;
            case ENG:
                return ENG.LIST_COUNTRY;
            default:
                return PT.LIST_COUNTRY;
        }
    }

    /// Region
    public static String getASK_REGION_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_REGION_NAME;
            case ENG:
                return ENG.ASK_REGION_NAME;
            default:
                return PT.ASK_REGION_NAME;
        }
    }

    public static String getASK_REGION_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_REGION_ID;
            case ENG:
                return ENG.ASK_REGION_ID;
            default:
                return PT.ASK_REGION_ID;
        }
    }

    public static String getregion_success(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.region_success(nome);
            case ENG:
                return ENG.region_success(nome);
            default:
                return PT.region_success(nome);
        }
    }

    public static String getregion_error(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.region_error(nome);
            case ENG:
                return ENG.region_error(nome);
            default:
                return PT.region_error(nome);
        }
    }

    public static String getregion_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.region_no_exist(id);
            case ENG:
                return ENG.region_no_exist(id);
            default:
                return PT.region_no_exist(id);
        }

    }

    public static String getLIST_REGION(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_REGION;
            case ENG:
                return ENG.LIST_REGION;
            default:
                return PT.LIST_REGION;
        }
    }

    /// Producer
    public static String getASK_PRODUCER_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRODUCER_NAME;
            case ENG:
                return ENG.ASK_PRODUCER_NAME;
            default:
                return PT.ASK_PRODUCER_NAME;
        }
    }

    public static String getASK_PRODUCER_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRODUCER_ID;
            case ENG:
                return ENG.ASK_PRODUCER_ID;
            default:
                return PT.ASK_PRODUCER_ID;
        }
    }

    public static String getproducer_success(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.producer_success(nome);
            case ENG:
                return ENG.producer_success(nome);
            default:
                return PT.producer_success(nome);
        }
    }

    public static String getproducer_error(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.producer_error(nome);
            case ENG:
                return ENG.producer_error(nome);
            default:
                return PT.producer_error(nome);
        }
    }

    public static String getproducer_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.producer_no_exist(id);
            case ENG:
                return ENG.producer_no_exist(id);
            default:
                return PT.producer_no_exist(id);
        }

    }

    public static String getLIST_PRODUCER(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_PRODUCER;
            case ENG:
                return ENG.LIST_PRODUCER;
            default:
                return PT.LIST_PRODUCER;
        }
    }

    /// Wine Type
    public static String getASK_WINE_TYPE_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_TYPE_NAME;
            case ENG:
                return ENG.ASK_WINE_TYPE_NAME;
            default:
                return PT.ASK_WINE_TYPE_NAME;
        }
    }

    public static String getASK_WINE_TYPE_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_TYPE_ID;
            case ENG:
                return ENG.ASK_WINE_TYPE_ID;
            default:
                return PT.ASK_WINE_TYPE_ID;
        }
    }

    public static String getwine_type_success(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.wine_type_success(nome);
            case ENG:
                return ENG.wine_type_success(nome);
            default:
                return PT.wine_type_success(nome);
        }
    }

    public static String getwine_type_error(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.wine_type_error(nome);
            case ENG:
                return ENG.wine_type_error(nome);
            default:
                return PT.wine_type_error(nome);
        }
    }

    public static String getwine_type_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.wine_type_no_exist(id);
            case ENG:
                return ENG.wine_type_no_exist(id);
            default:
                return PT.wine_type_no_exist(id);
        }

    }

    public static String getLIST_WINE_TYPE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_WINE_TYPE;
            case ENG:
                return ENG.LIST_WINE_TYPE;
            default:
                return PT.LIST_WINE_TYPE;
        }
    }

    /// Wine 
    public static String getASK_WINE_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_NAME;
            case ENG:
                return ENG.ASK_WINE_NAME;
            default:
                return PT.ASK_WINE_NAME;
        }
    }

    public static String getASK_WINE_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_ID;
            case ENG:
                return ENG.ASK_WINE_ID;
            default:
                return PT.ASK_WINE_ID;
        }
    }

    public static String getwine_success(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.wine_success(nome);
            case ENG:
                return ENG.wine_success(nome);
            default:
                return PT.wine_success(nome);
        }
    }

    public static String getwine_error(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.wine_error(nome);
            case ENG:
                return ENG.wine_error(nome);
            default:
                return PT.wine_error(nome);
        }
    }

    public static String getLIST_WINE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_WINE;
            case ENG:
                return ENG.LIST_WINE;
            default:
                return PT.LIST_WINE;
        }
    }

    public static String getwine_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.wine_no_exist(id);
            case ENG:
                return ENG.wine_no_exist(id);
            default:
                return PT.wine_no_exist(id);
        }
    }

    /// Wine Edition
    public static String getASK_WINE_EDITION_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_EDITION_ID;
            case ENG:
                return ENG.ASK_WINE_EDITION_ID;
            default:
                return PT.ASK_WINE_EDITION_ID;
        }
    }

    public static String getASK_WINE_EDITION_YEAR(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_WINE_EDITION_YEAR;
            case ENG:
                return ENG.ASK_WINE_EDITION_YEAR;
            default:
                return PT.ASK_WINE_EDITION_YEAR;
        }
    }

    public static String getwine_edition_success(Idiomas idioma, int ano, int vinho) {
        switch (idioma) {
            case PT:
                return PT.wine_edition_success(ano, vinho);
            case ENG:
                return ENG.wine_edition_success(ano, vinho);
            default:
                return PT.wine_edition_success(ano, vinho);
        }
    }

    public static String getwine_edition_error(Idiomas idioma, int ano, int vinho) {
        switch (idioma) {
            case PT:
                return PT.wine_edition_error(ano, vinho);
            case ENG:
                return ENG.wine_edition_error(ano, vinho);
            default:
                return PT.wine_edition_error(ano, vinho);
        }
    }

    public static String getwine_edition_no_exist(Idiomas idioma, int vinho) {
        switch (idioma) {
            case PT:
                return PT.wine_edition_no_exist(vinho);
            case ENG:
                return ENG.wine_edition_no_exist(vinho);
            default:
                return PT.wine_edition_no_exist(vinho);
        }
    }

    public static String getLIST_WINE_EDITION(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.LIST_WINE_EDITION;
            case ENG:
                return ENG.LIST_WINE_EDITION;
            default:
                return PT.LIST_WINE_EDITION;
        }
    }

    /// Seller
    public static String getASK_SELLER_NAME(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_SELLER_NAME;
            case ENG:
                return ENG.ASK_SELLER_NAME;
            default:
                return PT.ASK_SELLER_NAME;
        }
    }

    public static String getASK_SELLER_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_SELLER_ID;
            case ENG:
                return ENG.ASK_SELLER_ID;
            default:
                return PT.ASK_SELLER_ID;
        }
    }

    public static String getseller_success(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.seller_success(nome);
            case ENG:
                return ENG.seller_success(nome);
            default:
                return PT.seller_success(nome);
        }
    }

    public static String getseller_error(Idiomas idioma, String nome) {
        switch (idioma) {
            case PT:
                return PT.seller_error(nome);
            case ENG:
                return ENG.seller_error(nome);
            default:
                return PT.seller_error(nome);
        }
    }

    public static String getseller_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.seller_no_exist(id);
            case ENG:
                return ENG.seller_no_exist(id);
            default:
                return PT.seller_no_exist(id);
        }

    }

    /// Product
    public static String getASK_PRODUCT_URL(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRODUCT_URL;
            case ENG:
                return ENG.ASK_PRODUCT_URL;
            default:
                return PT.ASK_PRODUCT_URL;
        }
    }

    public static String getASK_PRODUCT_CODE(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRODUCT_CODE;
            case ENG:
                return ENG.ASK_PRODUCT_CODE;
            default:
                return PT.ASK_PRODUCT_CODE;
        }
    }

    public static String getASK_PRODUCT_ID(Idiomas idioma) {
        switch (idioma) {
            case PT:
                return PT.ASK_PRODUCT_ID;
            case ENG:
                return ENG.ASK_PRODUCT_ID;
            default:
                return PT.ASK_PRODUCT_ID;
        }
    }

    public static String getproduct_success(Idiomas idioma, String url) {
        switch (idioma) {
            case PT:
                return PT.product_success(url);
            case ENG:
                return ENG.product_success(url);
            default:
                return PT.product_success(url);
        }
    }

    public static String getproduct_error(Idiomas idioma, String url) {
        switch (idioma) {
            case PT:
                return PT.product_error(url);
            case ENG:
                return ENG.product_error(url);
            default:
                return PT.product_error(url);
        }
    }

    public static String getproduct_no_exist(Idiomas idioma, int id) {
        switch (idioma) {
            case PT:
                return PT.product_no_exist(id);
            case ENG:
                return ENG.product_no_exist(id);
            default:
                return PT.product_no_exist(id);
        }

    }

}
