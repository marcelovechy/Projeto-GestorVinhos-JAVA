package app.idiomas;

public class PT {

    // Menu Principal
    public static String MenuPrincipal="Menu Principal";
    public static String EscolherIdioma = "Change to English";
    public static String OpenMenuGerir = "Abrir Menu Gerir Vinhos";
    public static String OpenMenuConsultas = "Abrir Menu Consultas";
    public static String OpenMenuAtualizar = "Abrir Menu Preços";
    public static String SaveApp = "Salvar Aplicação";
    public static String LoadApp = "Carregar Ficheiro";

    // Menu Gerir
    public static String MENU_GERIR = "Menu de Gestão de Vinhos";
    public static String ADD_COUNTRY = "Adicionar País";
    public static String ADD_REGION = "Adicionar Região de Produção";
    public static String ADD_PRODUCER = "Adicionar Produtor";
    public static String ADD_WINE_TYPE = "Adicionar Tipo de Vinho";
    public static String ADD_WINE = "Adicionar Vinho";
    public static String ADD_WINE_EDITION = "Adicionar Edição de Vinho";
    public static String ADD_SELLER = "Adicionar Vendedor";
    public static String ADD_PRODUCT = "Adicionar Produto";


    // Menu CONSULTAS
    public static String MENU_CONSULTAS = "Menu Consultas";
    public static String LIST_COUNTRY = "Listar Países";
    public static String LIST_REGION = "Listar Regiões";
    public static String LIST_PRODUCER = "Listar Produtores";
    public static String LIST_WINE_TYPE = "Listar Tipo de Vinho";
    public static String LIST_WINE = "Listar Vinhos";
    public static String LIST_WINE_EDITION = "Listar Edição de Vinhos";
    public static String LIST_WINE_COUNTRY = "Listar Vinhos de um País";

    // Menu PRICES
    public static String MENU_PRECOS = "Menu Preços";
    public static String ADD_PRICE = "Adicionar Preço";

    /// Country
    public static String ASK_COUNTRY_NAME = "Insira o nome do País: ";
    public static String ASK_COUNTRY_CODE = "Insira o código do País: ";
    public static String country_success(String code) {
        return "País [" + code + "] adicionado com sucesso";
    }
    public static String country_error(String code) {
        return "País [" + code + "] já existe";
    }
    public static String country_no_exist(String code) {
        return "Pais [" + code + "] não existe";
    }

    /// Region 
    public static String ASK_REGION_NAME = "Insira o nome da Região: ";
    public static String ASK_REGION_ID = "Insira o ID da Região: ";
    public static String region_success(String nome) {
        return "Região [" + nome + "] adicionado com sucesso";
    }
    public static String region_error(String nome) {
        return "Região [" + nome + "] já existe";
    }
    public static String region_no_exist(int id) {
        return "Região [" + id + "] não existe";
    }

    /// Producer
    public static String ASK_PRODUCER_NAME = "Insira o nome do produtor: ";
    public static String ASK_PRODUCER_ID = "Insira o ID do produtor: ";
    public static String producer_success(String nome) {
        return "Produtor [" + nome + "] adicionado com sucesso";
    }
    public static String producer_error(String nome) {
        return "Produtor [" + nome + "] já existe";
    }
    public static String producer_no_exist(int id) {
        return "Produtor [" + id + "] não existe";
    }

    /// Wine Type 
    public static String ASK_WINE_TYPE_NAME = "Insira o tipo de vinho: ";
    public static String ASK_WINE_TYPE_ID = "Insira o ID do tipo de vinho: ";
    public static String wine_type_success(String nome) {
        return "Tipo de vinho [" + nome + "] adicionado com sucesso";
    }
    public static String wine_type_error(String nome) {
        return "Tipo de vinho [" + nome + "] já existe";
    }
    public static String wine_type_no_exist(int id) {
        return "Tipo de vinho [" + id + "] não existe";
    }

    /// Wine
    public static String ASK_WINE_NAME = "Insira o nome do vinho: ";
    public static String ASK_WINE_ID = "Insira o ID do vinho: ";
    public static String wine_success(String nome) {
        return "Vinho [" + nome + "] adicionado com sucesso";
    }
    public static String wine_error(String nome) {
        return "Vinho [" + nome + "] já existe";
    }
    public static String wine_no_exist(int id) {
        return "Vinho [" + id + "] não existe";
    }

    /// Wine Edition
    public static String ASK_WINE_EDITION_ID = "Insira o ID da Edição: ";
    public static String ASK_WINE_EDITION_YEAR = "Insira o ano da Edição: ";
    public static String wine_edition_success(int ano, int vinho) {
        return "Edição ["+ ano +"] do Vinho com ID [" + vinho+ "] adicionada com sucesso";
    }
    public static String wine_edition_error(int ano, int vinho) {
        return "Edição ["+ ano +"] do Vinho com ID [" + vinho+ "] já existe";
    }
    public static String wine_edition_no_exist(int vinho) {
        return "Edição do Vinho com ID [" + vinho+ "] não existe";
    }

    /// Seller
    public static String ASK_SELLER_NAME = "Insira o nome do Vendedor: ";
    public static String ASK_SELLER_ID = "Insira o ID do Vendedor: ";
    public static String seller_success(String nome) {
        return "Vendedor [" + nome + "] adicionado com sucesso";
    }
    public static String seller_error(String nome) {
        return "Vendedor [" + nome + "] já existe";
    }
    public static String seller_no_exist(int id) {
        return "Vendedor [" + id + "] não existe";
    }

    /// Product 
    public static String ASK_PRODUCT_URL = "Insira o URL do Produto: ";
    public static String ASK_PRODUCT_CODE = "Insira o código do Produto: ";
    public static String ASK_PRODUCT_ID = "Insira o ID do Produto: ";
    public static String product_success(String url) {
        return "Produto [" + url + "] adicionado com sucesso";
    }
    public static String product_error(String url) {
        return "Produto [" + url + "] já existe";
    }
    public static String product_no_exist(int id) {
        return "Produto [" + id + "] não existe";
    }

    /// Price 
    public static String ASK_PRICE_VALUE = "Insira o preço do Produto: ";
    public static String ASK_PRICE_DATA = "Insira a data: ";
    public static String price_success(double valor) {
        return "Produto com preço [" + valor + "] adicionado com sucesso";
    }
    public static String price_error(int produto, double valor) {
        return "Produto com ID [" + produto + "] e com preço [" + valor + "] já existe";
    }
    
}
