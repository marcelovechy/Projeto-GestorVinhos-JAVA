package app.consultas;

import java.util.ArrayList;

import vinhos.TipoVinho;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListWineType extends Comando<GestorVinhos> {

    public DoListWineType(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<TipoVinho> todosTipoVinho = this.getReceptor().listarTipoVinho();
        this.ui.escreveLinha(GestorIdiomas.getLIST_WINE_TYPE(receptor.getIdioma()));
        for (TipoVinho vinhos : todosTipoVinho) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}
