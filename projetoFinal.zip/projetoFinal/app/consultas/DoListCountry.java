package app.consultas;

import java.util.ArrayList;

import vinhos.Pais;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListCountry extends Comando<GestorVinhos> {

    public DoListCountry(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<Pais> todosPais = this.getReceptor().listarPais();
        this.ui.escreveLinha(GestorIdiomas.getLIST_COUNTRY(receptor.getIdioma()));
        for (Pais vinhos : todosPais) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}