package app.consultas;

import java.util.ArrayList;

import vinhos.Produtor;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListProducer extends Comando<GestorVinhos> {

    public DoListProducer(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<Produtor> todosProdutor = this.getReceptor().listarProdutor();
        this.ui.escreveLinha(GestorIdiomas.getLIST_PRODUCER(receptor.getIdioma()));
        for (Produtor vinhos : todosProdutor) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}