package app.consultas;

import vinhos.GestorVinhos;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.exceptions.DialogException;

public class Menu extends ui.Menu{

    public Menu(GestorVinhos vinhos) {
       super(GestorIdiomas.getMENU_CONSULTAS(vinhos.getIdioma()), new Comando<?>[]{
            new DoListCountry(vinhos, GestorIdiomas.getLIST_COUNTRY(vinhos.getIdioma())),
            new DoListRegion(vinhos, GestorIdiomas.getLIST_REGION(vinhos.getIdioma())),
            new DoListProducer(vinhos, GestorIdiomas.getLIST_PRODUCER(vinhos.getIdioma())),
            new DoListWineType(vinhos, GestorIdiomas.getLIST_WINE_TYPE(vinhos.getIdioma())),
            new DoListWine(vinhos, GestorIdiomas.getLIST_WINE(vinhos.getIdioma())),
            new DoListWineEdition(vinhos, GestorIdiomas.getLIST_WINE_EDITION(vinhos.getIdioma()))

        });
    }
    
}
