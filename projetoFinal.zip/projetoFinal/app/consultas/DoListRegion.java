package app.consultas;

import java.util.ArrayList;

import vinhos.Regiao;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListRegion extends Comando<GestorVinhos> {

    public DoListRegion(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<Regiao> todosRegiao = this.getReceptor().listarRegiao();
        this.ui.escreveLinha(GestorIdiomas.getLIST_REGION(receptor.getIdioma()));
        for (Regiao vinhos : todosRegiao) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}
