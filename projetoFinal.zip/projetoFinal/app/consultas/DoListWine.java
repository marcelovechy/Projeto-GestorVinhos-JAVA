package app.consultas;

import java.util.ArrayList;

import vinhos.Vinho;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListWine extends Comando<GestorVinhos> {

    public DoListWine(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<Vinho> todosVinho = this.getReceptor().listarVinho();
        this.ui.escreveLinha(GestorIdiomas.getLIST_WINE(receptor.getIdioma()));
        for (Vinho vinhos : todosVinho) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}
