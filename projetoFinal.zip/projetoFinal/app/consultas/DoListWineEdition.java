package app.consultas;

import java.util.ArrayList;

import vinhos.EdicaoVinho;
import vinhos.Idiomas;
import app.idiomas.GestorIdiomas;
import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoListWineEdition extends Comando<GestorVinhos> {

    public DoListWineEdition(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");
        ArrayList<EdicaoVinho> todosEdicaoVinho = this.getReceptor().listarEdicaoVinho();
        this.ui.escreveLinha(GestorIdiomas.getLIST_WINE_EDITION(receptor.getIdioma()));
        for (EdicaoVinho vinhos : todosEdicaoVinho) {
            this.ui.escreveLinha(vinhos.toString());
        }

    }

}
