package app.main;

import app.gerir.Menu;
import ui.Comando;
import ui.exceptions.DialogException;
import vinhos.GestorVinhos;

public class DoAbrirMenuGerir extends Comando<GestorVinhos>{

    public DoAbrirMenuGerir(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);
    }

    @Override
    public void executar() throws DialogException {
        Menu m=new Menu(this.getReceptor());
        m.open();
        
    }
    
 
}
