package app.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoSaveApp extends Comando<GestorVinhos> {

    public DoSaveApp(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");

        GestorVinhos gv = new GestorVinhos("Adega");
        File f_escrita = new File("adega.in");

        try {
            f_escrita.createNewFile();
            FileOutputStream fos = new FileOutputStream(f_escrita);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(gv);
            oos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

}
