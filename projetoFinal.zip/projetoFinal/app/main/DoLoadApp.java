package app.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import vinhos.GestorVinhos;
import ui.Comando;
import ui.exceptions.DialogException;

public class DoLoadApp extends Comando<GestorVinhos> {

    public DoLoadApp(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);

    }

    @Override
    public void executar() throws DialogException {
        System.out.println("\033[H\033[2J");

        GestorVinhos gv = new GestorVinhos("Adega");
        File f_leitura = new File("adega.in");
        
        try {
            FileInputStream fis = new FileInputStream(f_leitura);
            ObjectInputStream ois = new ObjectInputStream(fis);
            gv = (GestorVinhos) ois.readObject();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }

    }

}
