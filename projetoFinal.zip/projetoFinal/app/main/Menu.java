package app.main;

import vinhos.GestorVinhos;
import app.idiomas.GestorIdiomas;
import ui.Comando;
import ui.exceptions.DialogException;

public class Menu extends ui.Menu {

    /**
     * Construtor do Menu. São carregados todos os comandos do menu.
     * @param vinhos
     */
    public Menu(GestorVinhos vinhos) {
        super(GestorIdiomas.getMenuPrincipal(vinhos.getIdioma()), new Comando<?>[]{
            new DoEscolherIdioma(vinhos, GestorIdiomas.getEscolherIdioma(vinhos.getIdioma())),
            new DoAbrirMenuGerir(vinhos, GestorIdiomas.getOpenMenuGerir(vinhos.getIdioma())),
            new DoAbrirMenuConsultas(vinhos, GestorIdiomas.getOpenMenuConsultas(vinhos.getIdioma())),
            new DoAbrirMenuPrices(vinhos, GestorIdiomas.getOpenMenuAtualizar(vinhos.getIdioma())),
            new DoSaveApp(vinhos, GestorIdiomas.getSaveApp(vinhos.getIdioma())),
            new DoLoadApp(vinhos, GestorIdiomas.getLoadApp(vinhos.getIdioma()))
            
        });
    }
}
