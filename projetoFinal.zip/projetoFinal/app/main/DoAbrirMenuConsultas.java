package app.main;

import app.consultas.Menu;
import ui.Comando;
import ui.exceptions.DialogException;
import vinhos.GestorVinhos;

public class DoAbrirMenuConsultas extends Comando<GestorVinhos>{

    public DoAbrirMenuConsultas(GestorVinhos receptor, String titulo) {
        super(receptor, titulo);
    }

    @Override
    public void executar() throws DialogException {
        Menu m=new Menu(this.getReceptor());
        m.open();
        
    }
    
 
}
